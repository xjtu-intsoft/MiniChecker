App({
    onLaunch: function(){ 
    },
    init: function(){
        var that = this;
        my.getAuthCode({
            scopes: ['auth_user'],
            success: res => {
                console.log(res);
            },
            fail: res => {
                that.handleErr(res);
            }
        })
    },
    handleErr: function(e){
        this.init();
    }
})