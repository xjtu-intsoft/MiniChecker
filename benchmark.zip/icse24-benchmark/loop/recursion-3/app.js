App({
    onLaunch: function(){ 
    },
    init: function(){
        my.getAuthCode({
            scopes: ['auth_user'],
            success: res => {
                console.log(res);
            }
        })
        this.init2();
    },
    init2: function(){
        this.init();
    }
})