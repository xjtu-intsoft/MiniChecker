const app = getApp();

Page({
    data: {},
    onLoad: function () { },
    async onAuthorize() {
        try {
            await app.getUserAuth(['auth_user'])
        } catch (error) {
            my.showToast({
                type: "fail",
                content: 'need authorize',
                duration: 1000,
                success: () => {
                    this.onAuthorize()
                },
            });
        }
    }
})
