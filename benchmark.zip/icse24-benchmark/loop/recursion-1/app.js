App({
    onLaunch: function(){ 
    },
    init: function(){
    }
})