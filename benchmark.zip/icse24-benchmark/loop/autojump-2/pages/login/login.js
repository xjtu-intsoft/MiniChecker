Page({
    data:{},
    onLoad: function(){
        my.navigateTo({
            url: '/pages/home/home'
        })
    }
})