Page({
    data:{},
    onLoad: function(){
        this.init();
    },
    init: function() {
        my.getAuthCode({
            scopes: ['auth_user'],
            success: res => {
                console.log(res);
            },
            fail: res => {
                console.log(res);
                my.alert({
                    title: 'err',
                    content: 'auth err',
                    buttonText: 'relogin',
                    success: () => {
                        my.navigateTo({
                            url: '/pages/login/login'
                        });
                    }
                });
            }
        })
    }
})