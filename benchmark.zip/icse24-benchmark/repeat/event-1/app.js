App({
    onLaunch: function(){
       
    },
    authHandler: function(){
        my.getAuthCode({
            scopes: ['auth_user'],
            success: res => {
                console.log(res);
            }
        })
    }
})