Page({
    data:{},
    onLoad: function(){
        this.init();
    },
    init: function() {
        my.getAuthCode({
            scopes: ['auth_user'],
            success: res => {
                console.log(res);
            }
        })
    },
    toLogin: function(){
        my.navigateTo({
            url: '/pages/login/login'
        })
    },
})