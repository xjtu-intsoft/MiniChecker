App({
    onLaunch: function(){ },
    getUserAuth: function(e){
        my.getAuthCode({
            scopes: e,
            success: res => {
                console.log(res);
            }
        })
    }
})