Page({
    data:{},
    onLoad: function(){}
})