Page({
    data:{},
    onLoad: function(){
        this.init();
    },
    init: function(){
        var that = this;
        my.getAuthCode({
            scopes: ['auth_user'],
            success: res => {
                console.log(res);
            },
            fail: res => {
                that.init();
            }
        })
    }
})