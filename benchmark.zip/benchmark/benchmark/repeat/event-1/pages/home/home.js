const app = getApp();

Page({
    data:{},
    onLoad: function(){
    },
    onGetAuthorize: function(){
        this.getUserInfo();
    },
    getUserInfo: function(){
        my.getOpenUserInfo({
            type: 'gcj02',
            success: function(res) {
              console.log(res);
              app.authHandler();
            }
        })
    }
})