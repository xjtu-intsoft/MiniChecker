Page({
    data:{},
    onLoad: function(){
        my.getLocation({
            type: 'gcj02',
            success: function(res) {
              console.log(res);
            }
        })
    }
})