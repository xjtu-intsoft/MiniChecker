import auth from './common/auth.js'
App({
    onLaunch: function(){
        auth()
    }
})