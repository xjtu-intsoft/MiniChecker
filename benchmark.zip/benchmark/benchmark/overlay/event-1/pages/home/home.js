Page({
    data:{},
    onLoad: function(){},
    handleScan: function(){
        var that = this;
        my.scan({
            success: function(res) {
                that.uploadResult(res.result);
            }
        });
    },
    uploadResult: function(e){
        my.getAuthCode({
            scopes: ["auth_code"],
            success: res => {
                console.log(res);
            }
        })
    }
})