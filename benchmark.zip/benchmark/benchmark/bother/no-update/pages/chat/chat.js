Page({
    data:{
        needAuth: true
    },
    onLoad: function(){
        var that = this;
        if(needAuth){
            my.getAuthCode({
                scopes: ['auth_user'],
                success: res => {
                    that.data.needAuth = false;
                    console.log(res);
                },
                fail: res => {
                    my.switchTab({
                        url: "pages/home/home"
                    });
                }
            })
        }
    }
})