Page({
    data:{},
    onLoad: function(){
        my.getAuthCode({
            scopes: ['auth_user'],
            success: res => {
                console.log(res);
            },
            fail: res => {
                my.switchTab({
                    url: "pages/home/home"
                });
            }
        })
    }
})